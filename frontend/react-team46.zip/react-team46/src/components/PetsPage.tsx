// src/HomePage.js
import React from "react";

function PetsPage() {
  return (
    <div style={styles.container}>
      <h1>Pets 1</h1>
    </div>
  );
}

const styles = {
  container: {
    textAlign: "center",
    marginTop: "20px",
  },
  button: {
    padding: "10px 20px",
    fontSize: "16px",
    cursor: "pointer",
  },
};

export default PetsPage;
